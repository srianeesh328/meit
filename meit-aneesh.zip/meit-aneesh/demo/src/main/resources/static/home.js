'use strict';
function menuroommates(event){
    event.preventDefault();
    document.location.href="/roommate.html";
}
function menulists(event){
    event.preventDefault();
    document.location.href="/user_lists.html";
}
function menuaccounts(event){
    event.preventDefault();
    document.location.href="/account.html";
}