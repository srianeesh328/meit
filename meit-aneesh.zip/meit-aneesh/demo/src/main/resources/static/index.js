
'use strict';
function openregister(event){
    event.preventDefault();
    document.location.href="/register.html";
}

function openlogin(event){
    event.preventDefault();
    document.location.href="/login.html";
}

